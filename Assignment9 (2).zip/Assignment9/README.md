#Backend

Folder Structure:

Index.js -> entry point for the application. Index.js also contains the Mongoose connect and port details. From index -> Routes.js is called.

Routes.js -> this file consists all the api calls.

userController.js -> acts as a middleware for the db queries. All the queries are defined in this controller file.

User.js -> the user model with Email, password and username are defined in this file.

#FrontEnd

React Login Page and Pages with React Router
This project implements a React login page that authenticates users with a backend API and four pages (Home, About, Jobs, and Contact) created using React components and React Router. Each page includes a card component that provides more information about the page's content.

index.js -> entry point for the application.

App.js -> Routes are defined in this file.

Nav.js + nav.css -> Navigation bar is designed.

Login.js + Login.css -> Login form is designed and validated.

#Backend Integration files

I have used MVC architecture:

From the Login screen, I have called userLogin present in userAction.js which calls the userServiceLogin.js.

From userServiceLogin.js the post/login url is hit using 'Axios'. Now, the response from the REST API is passed back to the login page. In the Login page I have checked the validate boolean which is returned as true if the user credentials are correct else is returned as false. If validate is true, the user is navigated to the HOME page else an ALERT is popped asking the user to enter valid credentials.




