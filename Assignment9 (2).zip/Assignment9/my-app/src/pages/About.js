import React from "react";
import CardComponent from "../Card/CardComponent";
import job_img1 from "../Assests/icons/amazon.png"
import job_img2 from "../Assests/icons/apple.png"
import job_img3 from "../Assests/icons/google.png"
import job_img4 from "../Assests/icons/microsoft.png"
import job_img5 from "../Assests/icons/netflix.png"
import imgslider1 from "../Assests/amazon.jpeg"
import imgslider2 from "../Assests/apple.png"
import imgslider3 from "../Assests/google.png"
import imgslider4 from "../Assests/microsoft.png"
import imgslider5 from "../Assests/netflix.png"
import SlideImage from './imageSlider'
import './About.css'

function About(){

    let data=[{
        title:"Amazon",
        imageUrl:job_img1,
        body:"Amazon.com, Inc. is an American multinational technology company focusing on e-commerce, cloud computing, online advertising, digital streaming, and artificial intelligence. It has been referred to as one of the most influential economic and cultural forces in the world, and is one of the world's most valuable brands.[6] It is one of the Big Five American information technology companies, alongside Alphabet (Google), Apple, Meta (Facebook), and Microsoft."
    },

    {
        title:"Apple",
        imageUrl:job_img2,
        body:"Apple Inc. is an American multinational technology company headquartered in Cupertino, California. Apple is the largest technology company by revenue, totaling US$394.3 billion in 2022.[6] As of March 2023, Apple is the world's biggest company by market capitalization.[7] As of June 2022, Apple is the fourth-largest personal computer vendor by unit sales and second-largest mobile phone manufacturer. It is one of the Big Five American information technology companies, alongside Alphabet (known for Google), Amazon, Meta (known for Facebook), and Microsoft."
    },
    {
        title:"Google",
        imageUrl:job_img3,
        body:"Google is an American multinational technology company focusing on online advertising, search engine technology, cloud computing, computer software, quantum computing, e-commerce, artificial intelligence,[9] and consumer electronics. It has often been referred to as the most powerful company in the world and one of the world's most valuable brands due to its market dominance, data collection, and technological advantages in the area of artificial intelligence.[11][12][13] Its parent company Alphabet is considered one of the Big Five American information technology companies, alongside Amazon, Apple, Meta, and Microsoft."
    },
    {
        title:"Microsoft",
        imageUrl:job_img4,
        body:"Microsoft Corporation is an American multinational technology corporation headquartered in Redmond, Washington. Microsoft's best-known software products are the Windows line of operating systems, the Microsoft Office suite, and the Internet Explorer and Edge web browsers. Its flagship hardware products are the Xbox video game consoles and the Microsoft Surface lineup of touchscreen personal computers. Microsoft ranked No. 14 in the 2022 Fortune 500 rankings of the largest United States corporations by total revenue;[2] it was the world's largest software maker by revenue as of 2022. It is considered as one of the Big Five American information technology companies, alongside Alphabet (parent company of Google), Amazon, Apple, and Meta (formerly Facebook)."
    },
    {
        title:"Netflix",
        imageUrl:job_img5,
        body:"Netflix, Inc. is an American media company based in Los Gatos, California. Founded in 1997 by Reed Hastings and Marc Randolph in Scotts Valley, California, it operates the over-the-top subscription video on-demand service Netflix brand, which includes original films and television series commissioned or acquired by the company, and third-party content licensed from other distributors. Netflix is a member of the Motion Picture Association—having become the first streaming company to become a member."
    }
]

    return(
        <div class="about_page">
        <div className='a_card'>
        {data.map(elem=>(
            <CardComponent
            title={elem.title}
            imageUrl={elem.imageUrl}
            body={elem.body}
        />
        ))}
    </div>
            
        </div>
    )
}

export default About